# Posture Reminder System (Java)

This program reminds users to fix their posture at user-defined intervals.

How to run:
1. cd PostureReminder_Compliant/src
2. javac *.java
3. java Main
